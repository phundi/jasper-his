-- MySQL dump 10.13  Distrib 8.0.26, for Linux (x86_64)
--
-- Host: localhost    Database: hmis
-- ------------------------------------------------------
-- Server version	8.0.26-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `client`
--

DROP TABLE IF EXISTS `client`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `client` (
  `client_id` int NOT NULL AUTO_INCREMENT,
  `identifier` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `first_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `middle_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `first_name_code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_name_code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `client_type_id` int NOT NULL,
  `gender` tinyint NOT NULL DEFAULT '0',
  `birthdate` date DEFAULT NULL,
  `occupation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`client_id`),
  KEY `fk_client_1` (`client_type_id`),
  CONSTRAINT `fk_client_1` FOREIGN KEY (`client_type_id`) REFERENCES `client_type` (`client_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client`
--

LOCK TABLES `client` WRITE;
/*!40000 ALTER TABLE `client` DISABLE KEYS */;
INSERT INTO `client` VALUES (1,NULL,'Test',NULL,'Patient','T63','P353',1,1,'2021-06-22','Ttetet','','0991876332','','2021-06-24 11:39:12','2022-03-16 07:43:22'),(2,NULL,'Jasper',NULL,'CHisi','Y614','96',1,1,'2022-03-08','','Area 23','0999777888','','2022-03-16 07:40:42','2022-03-16 07:40:42'),(3,NULL,'Kondwani',NULL,'Banda','K538','B53',1,1,'2022-01-03','','Area 49','0998654231','','2022-04-04 08:47:11','2022-04-04 08:47:11');
/*!40000 ALTER TABLE `client` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `client_identifier`
--

DROP TABLE IF EXISTS `client_identifier`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `client_identifier` (
  `client_identifier_id` int NOT NULL AUTO_INCREMENT,
  `value` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `client_id` int NOT NULL,
  `client_identifier_type_id` int NOT NULL,
  `voided` tinyint(1) NOT NULL DEFAULT '0',
  `voided_by` int DEFAULT NULL,
  `void_reason` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `creator` int NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`client_identifier_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client_identifier`
--

LOCK TABLES `client_identifier` WRITE;
/*!40000 ALTER TABLE `client_identifier` DISABLE KEYS */;
/*!40000 ALTER TABLE `client_identifier` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `client_identifier_type`
--

DROP TABLE IF EXISTS `client_identifier_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `client_identifier_type` (
  `client_identifier_type_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `voided` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`client_identifier_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client_identifier_type`
--

LOCK TABLES `client_identifier_type` WRITE;
/*!40000 ALTER TABLE `client_identifier_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `client_identifier_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `client_type`
--

DROP TABLE IF EXISTS `client_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `client_type` (
  `client_type_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `voided` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`client_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client_type`
--

LOCK TABLES `client_type` WRITE;
/*!40000 ALTER TABLE `client_type` DISABLE KEYS */;
INSERT INTO `client_type` VALUES (1,'Patient','',0,'2021-06-24 11:38:34','2021-06-24 11:38:34');
/*!40000 ALTER TABLE `client_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `concept`
--

DROP TABLE IF EXISTS `concept`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `concept` (
  `concept_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `creator` int DEFAULT NULL,
  `voided` tinyint(1) NOT NULL DEFAULT '0',
  `voided_by` int DEFAULT NULL,
  `void_reason` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`concept_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb3 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `concept`
--

LOCK TABLES `concept` WRITE;
/*!40000 ALTER TABLE `concept` DISABLE KEYS */;
INSERT INTO `concept` VALUES (1,'HIV Test Type',NULL,NULL,0,NULL,NULL,'2022-03-23 09:42:57','2022-03-23 09:42:57'),(2,'HIV Test Result',NULL,NULL,0,NULL,NULL,'2022-03-23 09:42:57','2022-03-23 09:42:57'),(3,'VL Test Type',NULL,NULL,0,NULL,NULL,'2022-03-23 09:42:57','2022-03-23 09:42:57'),(4,'VL Test Result',NULL,NULL,0,NULL,NULL,'2022-03-23 09:42:58','2022-03-23 09:42:58'),(5,'Specimen Type',NULL,NULL,0,NULL,NULL,'2022-03-25 05:09:47','2022-03-25 05:09:47'),(6,'VL Result (Copies/ML)',NULL,NULL,0,NULL,NULL,'2022-03-25 05:10:01','2022-03-25 05:13:07'),(7,'Outcome',NULL,NULL,0,NULL,NULL,'2022-03-25 05:23:31','2022-03-25 05:23:31');
/*!40000 ALTER TABLE `concept` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `concept_set`
--

DROP TABLE IF EXISTS `concept_set`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `concept_set` (
  `concept_set_id` int NOT NULL AUTO_INCREMENT,
  `concept_id` int DEFAULT NULL,
  `concept_set` int DEFAULT NULL,
  `creator` int DEFAULT NULL,
  `voided` tinyint(1) NOT NULL DEFAULT '0',
  `voided_by` int DEFAULT NULL,
  `void_reason` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`concept_set_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `concept_set`
--

LOCK TABLES `concept_set` WRITE;
/*!40000 ALTER TABLE `concept_set` DISABLE KEYS */;
/*!40000 ALTER TABLE `concept_set` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `department`
--

DROP TABLE IF EXISTS `department`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `department` (
  `department_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `creator` int DEFAULT NULL,
  `voided` tinyint(1) NOT NULL DEFAULT '0',
  `voided_by` int DEFAULT NULL,
  `void_reason` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`department_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `department`
--

LOCK TABLES `department` WRITE;
/*!40000 ALTER TABLE `department` DISABLE KEYS */;
/*!40000 ALTER TABLE `department` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `encounter`
--

DROP TABLE IF EXISTS `encounter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `encounter` (
  `encounter_id` int NOT NULL AUTO_INCREMENT,
  `encounter_type_id` int DEFAULT NULL,
  `workflow_id` int DEFAULT NULL,
  `encounter_datetime` datetime NOT NULL,
  `client_id` int NOT NULL,
  `creator` int DEFAULT NULL,
  `voided` tinyint(1) NOT NULL DEFAULT '0',
  `voided_by` int DEFAULT NULL,
  `void_reason` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`encounter_id`),
  KEY `fk_encounter_1` (`encounter_type_id`),
  KEY `fk_encounter_2` (`creator`),
  KEY `fk_encounter_3` (`voided_by`),
  KEY `fk_oencounter_4` (`client_id`),
  CONSTRAINT `fk_encounter_1` FOREIGN KEY (`encounter_type_id`) REFERENCES `encounter_type` (`encounter_type_id`),
  CONSTRAINT `fk_encounter_2` FOREIGN KEY (`creator`) REFERENCES `user` (`user_id`),
  CONSTRAINT `fk_encounter_3` FOREIGN KEY (`voided_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `fk_oencounter_4` FOREIGN KEY (`client_id`) REFERENCES `client` (`client_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb3 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `encounter`
--

LOCK TABLES `encounter` WRITE;
/*!40000 ALTER TABLE `encounter` DISABLE KEYS */;
INSERT INTO `encounter` VALUES (1,1,1,'2022-03-23 09:45:51',2,1,0,NULL,NULL,'2022-03-23 09:45:51','2022-03-23 09:45:51'),(2,1,1,'2022-03-23 09:47:38',2,1,0,NULL,NULL,'2022-03-23 09:47:38','2022-03-23 09:47:38'),(3,1,1,'2022-03-23 10:02:13',2,1,0,NULL,NULL,'2022-03-23 10:02:13','2022-03-23 10:02:13'),(4,1,1,'2022-03-23 10:02:54',2,1,0,NULL,NULL,'2022-03-23 10:02:54','2022-03-23 10:02:54'),(5,1,1,'2022-03-23 10:16:30',2,1,0,NULL,NULL,'2022-03-23 10:16:30','2022-03-23 10:16:30'),(6,1,1,'2022-03-24 07:12:18',2,1,0,NULL,NULL,'2022-03-24 07:12:18','2022-03-24 07:12:18'),(7,2,2,'2022-03-25 05:11:14',2,1,0,NULL,NULL,'2022-03-25 05:11:14','2022-03-25 05:11:14'),(8,2,2,'2022-03-25 05:14:24',2,1,0,NULL,NULL,'2022-03-25 05:14:24','2022-03-25 05:14:24'),(9,2,2,'2022-03-25 05:15:07',2,1,0,NULL,NULL,'2022-03-25 05:15:07','2022-03-25 05:15:07'),(10,2,2,'2022-03-25 05:15:13',2,1,0,NULL,NULL,'2022-03-25 05:15:13','2022-03-25 05:15:13'),(11,2,2,'2022-03-25 05:16:16',2,1,0,NULL,NULL,'2022-03-25 05:16:16','2022-03-25 05:16:16'),(12,1,1,'2022-03-25 05:18:55',2,1,0,NULL,NULL,'2022-03-25 05:18:55','2022-03-25 05:18:55'),(13,3,2,'2022-03-25 05:30:51',2,1,0,NULL,NULL,'2022-03-25 05:30:51','2022-03-25 05:30:51'),(14,3,2,'2022-03-25 05:31:05',2,1,0,NULL,NULL,'2022-03-25 05:31:05','2022-03-25 05:31:05'),(15,1,1,'2022-04-04 08:47:32',3,1,0,NULL,NULL,'2022-04-04 08:47:32','2022-04-04 08:47:32'),(16,2,2,'2022-04-04 08:51:38',3,1,0,NULL,NULL,'2022-04-04 08:51:38','2022-04-04 08:51:38');
/*!40000 ALTER TABLE `encounter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `encounter_type`
--

DROP TABLE IF EXISTS `encounter_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `encounter_type` (
  `encounter_type_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `creator` int DEFAULT NULL,
  `voided` tinyint(1) NOT NULL DEFAULT '0',
  `voided_by` int DEFAULT NULL,
  `void_reason` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`encounter_type_id`),
  KEY `fk_encounter_type_1` (`voided_by`),
  KEY `fk_encounter_type_2` (`creator`),
  CONSTRAINT `fk_encounter_type_1` FOREIGN KEY (`voided_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `fk_encounter_type_2` FOREIGN KEY (`creator`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `encounter_type`
--

LOCK TABLES `encounter_type` WRITE;
/*!40000 ALTER TABLE `encounter_type` DISABLE KEYS */;
INSERT INTO `encounter_type` VALUES (1,'HIV Test',NULL,0,NULL,NULL,'2022-03-23 09:32:12','2022-03-23 09:32:12'),(2,'Viral Load',NULL,0,NULL,NULL,'2022-03-25 04:57:47','2022-03-25 04:57:47'),(3,'Client Outcome',NULL,0,NULL,NULL,'2022-03-25 05:23:13','2022-03-25 05:23:13');
/*!40000 ALTER TABLE `encounter_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `location`
--

DROP TABLE IF EXISTS `location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `location` (
  `location_id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `postal_code` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `country` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `latitude` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `longitude` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `creator` int NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL,
  `county_district` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `voided` tinyint(1) NOT NULL DEFAULT '0',
  `voided_by` int DEFAULT NULL,
  `date_voided` datetime DEFAULT NULL,
  `void_reason` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `parent_location` int DEFAULT NULL,
  `changed_by` int DEFAULT NULL,
  `changed_at` datetime DEFAULT NULL,
  PRIMARY KEY (`location_id`),
  KEY `location_changed_by` (`changed_by`) USING BTREE,
  KEY `user_who_created_location` (`creator`) USING BTREE,
  KEY `name_of_location` (`name`) USING BTREE,
  KEY `parent_location` (`parent_location`) USING BTREE,
  KEY `retired_status` (`voided`) USING BTREE,
  KEY `user_who_retired_location` (`voided_by`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=35761 DEFAULT CHARSET=utf8mb3 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `location`
--

LOCK TABLES `location` WRITE;
/*!40000 ALTER TABLE `location` DISABLE KEYS */;
/*!40000 ALTER TABLE `location` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `location_tag`
--

DROP TABLE IF EXISTS `location_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `location_tag` (
  `location_tag_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locked` tinyint NOT NULL DEFAULT '0',
  `voided` tinyint NOT NULL DEFAULT '0',
  `voided_by` int DEFAULT NULL,
  `void_reason` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_voided` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`location_tag_id`),
  UNIQUE KEY `location_tag_map_id_UNIQUE` (`location_tag_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb3 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `location_tag`
--

LOCK TABLES `location_tag` WRITE;
/*!40000 ALTER TABLE `location_tag` DISABLE KEYS */;
/*!40000 ALTER TABLE `location_tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `location_tag_map`
--

DROP TABLE IF EXISTS `location_tag_map`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `location_tag_map` (
  `location_id` int NOT NULL,
  `location_tag_id` int NOT NULL,
  KEY `fk_location_tag_map_1` (`location_id`) USING BTREE,
  KEY `fk_location_tag_map_2_idx` (`location_tag_id`) USING BTREE,
  CONSTRAINT `fk_location_tag_map_1` FOREIGN KEY (`location_id`) REFERENCES `location` (`location_id`),
  CONSTRAINT `fk_location_tag_map_2` FOREIGN KEY (`location_tag_id`) REFERENCES `location_tag` (`location_tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `location_tag_map`
--

LOCK TABLES `location_tag_map` WRITE;
/*!40000 ALTER TABLE `location_tag_map` DISABLE KEYS */;
/*!40000 ALTER TABLE `location_tag_map` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `obs`
--

DROP TABLE IF EXISTS `obs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `obs` (
  `obs_id` int NOT NULL AUTO_INCREMENT,
  `concept_id` int NOT NULL,
  `workflow_id` int NOT NULL,
  `encounter_id` int NOT NULL,
  `value_numeric` int DEFAULT NULL,
  `value_coded` int DEFAULT NULL,
  `client_id` int NOT NULL,
  `value_datetime` datetime DEFAULT NULL,
  `value_text` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `obs_datetime` datetime NOT NULL,
  `creator` int DEFAULT NULL,
  `voided` tinyint(1) NOT NULL DEFAULT '0',
  `voided_by` int DEFAULT NULL,
  `void_reason` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`obs_id`),
  KEY `fk_obs_4` (`concept_id`),
  KEY `fk_obs_5` (`encounter_id`),
  KEY `fk_obs_6` (`value_coded`),
  KEY `fk_obs_7` (`client_id`),
  CONSTRAINT `fk_obs_4` FOREIGN KEY (`concept_id`) REFERENCES `concept` (`concept_id`),
  CONSTRAINT `fk_obs_5` FOREIGN KEY (`encounter_id`) REFERENCES `encounter` (`encounter_id`),
  CONSTRAINT `fk_obs_6` FOREIGN KEY (`value_coded`) REFERENCES `concept` (`concept_id`),
  CONSTRAINT `fk_obs_7` FOREIGN KEY (`client_id`) REFERENCES `client` (`client_id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb3 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `obs`
--

LOCK TABLES `obs` WRITE;
/*!40000 ALTER TABLE `obs` DISABLE KEYS */;
INSERT INTO `obs` VALUES (1,1,1,1,NULL,NULL,2,NULL,'Unigold','2022-03-23 09:45:51',1,0,NULL,NULL,'2022-03-23 09:45:51','2022-03-23 09:45:51'),(2,2,1,1,NULL,NULL,2,NULL,'Negative','2022-03-23 09:45:51',1,0,NULL,NULL,'2022-03-23 09:45:51','2022-03-23 09:45:51'),(3,1,1,2,NULL,NULL,2,NULL,'Unigold','2022-03-23 09:47:39',1,0,NULL,NULL,'2022-03-23 09:47:39','2022-03-23 09:47:39'),(4,2,1,2,NULL,NULL,2,NULL,'Negative','2022-03-23 09:47:39',1,0,NULL,NULL,'2022-03-23 09:47:39','2022-03-23 09:47:39'),(5,1,1,3,NULL,NULL,2,NULL,'Unigold','2022-03-23 10:02:13',1,0,NULL,NULL,'2022-03-23 10:02:13','2022-03-23 10:02:13'),(6,2,1,3,NULL,NULL,2,NULL,'Inconclusive','2022-03-23 10:02:13',1,0,NULL,NULL,'2022-03-23 10:02:13','2022-03-23 10:02:13'),(7,1,1,4,NULL,NULL,2,NULL,'Unigold','2022-03-23 10:02:54',1,0,NULL,NULL,'2022-03-23 10:02:54','2022-03-23 10:02:54'),(8,2,1,4,NULL,NULL,2,NULL,'Inconclusive','2022-03-23 10:02:54',1,0,NULL,NULL,'2022-03-23 10:02:54','2022-03-23 10:02:54'),(9,1,1,6,NULL,NULL,2,NULL,'Unigold','2022-03-24 07:12:18',1,0,NULL,NULL,'2022-03-24 07:12:18','2022-03-24 07:12:18'),(10,2,1,6,NULL,NULL,2,NULL,'Positive','2022-03-24 07:12:18',1,0,NULL,NULL,'2022-03-24 07:12:18','2022-03-24 07:12:18'),(11,5,2,7,NULL,NULL,2,NULL,'DBS','2022-03-25 05:11:14',1,0,NULL,NULL,'2022-03-25 05:11:14','2022-03-25 05:11:14'),(12,6,2,7,NULL,NULL,2,NULL,'11100','2022-03-25 05:11:14',1,0,NULL,NULL,'2022-03-25 05:11:14','2022-03-25 05:11:14'),(13,5,2,8,NULL,NULL,2,NULL,'Plasma','2022-03-25 05:14:24',1,0,NULL,NULL,'2022-03-25 05:14:24','2022-03-25 05:14:24'),(14,5,2,9,NULL,NULL,2,NULL,'Plasma','2022-03-25 05:15:07',1,0,NULL,NULL,'2022-03-25 05:15:07','2022-03-25 05:15:07'),(15,5,2,10,NULL,NULL,2,NULL,'Plasma','2022-03-25 05:15:13',1,0,NULL,NULL,'2022-03-25 05:15:13','2022-03-25 05:15:13'),(16,6,2,10,NULL,NULL,2,NULL,'<100','2022-03-25 05:15:13',1,0,NULL,NULL,'2022-03-25 05:15:13','2022-03-25 05:15:13'),(17,5,2,11,NULL,NULL,2,NULL,'DBS','2022-03-25 05:16:16',1,0,NULL,NULL,'2022-03-25 05:16:16','2022-03-25 05:16:16'),(18,6,2,11,NULL,NULL,2,NULL,'20000','2022-03-25 05:16:17',1,0,NULL,NULL,'2022-03-25 05:16:17','2022-03-25 05:16:17'),(19,1,1,12,NULL,NULL,2,NULL,'Rapid Test','2022-03-25 05:18:55',1,0,NULL,NULL,'2022-03-25 05:18:55','2022-03-25 05:18:55'),(20,2,1,12,NULL,NULL,2,NULL,'Positive','2022-03-25 05:18:56',1,0,NULL,NULL,'2022-03-25 05:18:56','2022-03-25 05:18:56'),(21,7,2,13,NULL,NULL,2,NULL,'On ART','2022-03-25 05:30:52',1,0,NULL,NULL,'2022-03-25 05:30:52','2022-03-25 05:30:52'),(22,7,2,14,NULL,NULL,2,NULL,'Transferred Out','2022-03-25 05:31:06',1,0,NULL,NULL,'2022-03-25 05:31:06','2022-03-25 05:31:06'),(23,1,1,15,NULL,NULL,3,NULL,'Unigold Test','2022-04-04 08:47:34',1,0,NULL,NULL,'2022-04-04 08:47:34','2022-04-04 08:47:34'),(24,2,1,15,NULL,NULL,3,NULL,'Negative','2022-04-04 08:47:35',1,0,NULL,NULL,'2022-04-04 08:47:35','2022-04-04 08:47:35'),(25,5,2,16,NULL,NULL,3,NULL,'Plasma','2022-04-04 08:51:42',1,0,NULL,NULL,'2022-04-04 08:51:42','2022-04-04 08:51:42'),(26,6,2,16,NULL,NULL,3,NULL,'78888','2022-04-04 08:51:43',1,0,NULL,NULL,'2022-04-04 08:51:43','2022-04-04 08:51:43');
/*!40000 ALTER TABLE `obs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `panel`
--

DROP TABLE IF EXISTS `panel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `panel` (
  `panel_id` int NOT NULL AUTO_INCREMENT,
  `panel_type_id` int DEFAULT NULL,
  `test_type_id` int DEFAULT NULL,
  `creator` int DEFAULT NULL,
  `voided` tinyint(1) NOT NULL DEFAULT '0',
  `voided_by` int DEFAULT NULL,
  `void_reason` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`panel_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `panel`
--

LOCK TABLES `panel` WRITE;
/*!40000 ALTER TABLE `panel` DISABLE KEYS */;
/*!40000 ALTER TABLE `panel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `panel_type`
--

DROP TABLE IF EXISTS `panel_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `panel_type` (
  `panel_type_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `creator` int DEFAULT NULL,
  `voided` tinyint(1) NOT NULL DEFAULT '0',
  `voided_by` int DEFAULT NULL,
  `void_reason` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`panel_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `panel_type`
--

LOCK TABLES `panel_type` WRITE;
/*!40000 ALTER TABLE `panel_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `panel_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permission`
--

DROP TABLE IF EXISTS `permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permission` (
  `permission_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `display_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`permission_id`),
  UNIQUE KEY `permission_name_unique` (`name`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permission`
--

LOCK TABLES `permission` WRITE;
/*!40000 ALTER TABLE `permission` DISABLE KEYS */;
/*!40000 ALTER TABLE `permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permission_role`
--

DROP TABLE IF EXISTS `permission_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permission_role` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permission_id` int NOT NULL,
  `role_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `permission_role_permission_id_foreign` (`permission_id`) USING BTREE,
  KEY `permission_role_role_id_foreign` (`role_id`) USING BTREE,
  CONSTRAINT `fk_permission_role_1` FOREIGN KEY (`permission_id`) REFERENCES `permission` (`permission_id`),
  CONSTRAINT `fk_permission_role_2` FOREIGN KEY (`role_id`) REFERENCES `role` (`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permission_role`
--

LOCK TABLES `permission_role` WRITE;
/*!40000 ALTER TABLE `permission_role` DISABLE KEYS */;
/*!40000 ALTER TABLE `permission_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rejection_reason`
--

DROP TABLE IF EXISTS `rejection_reason`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rejection_reason` (
  `rejection_reason_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `voided` tinyint(1) NOT NULL DEFAULT '0',
  `voided_by` int DEFAULT NULL,
  `void_reason` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`rejection_reason_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rejection_reason`
--

LOCK TABLES `rejection_reason` WRITE;
/*!40000 ALTER TABLE `rejection_reason` DISABLE KEYS */;
/*!40000 ALTER TABLE `rejection_reason` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role` (
  `role_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`role_id`),
  UNIQUE KEY `role_name_unique` (`name`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role`
--

LOCK TABLES `role` WRITE;
/*!40000 ALTER TABLE `role` DISABLE KEYS */;
INSERT INTO `role` VALUES (1,'Administrator','---','2021-06-24 11:33:04','2021-06-24 11:33:04'),(2,'Nurse','','2022-03-23 07:59:17','2022-03-23 07:59:17'),(3,'HTS councilor','','2022-03-24 07:04:22','2022-03-24 07:04:22');
/*!40000 ALTER TABLE `role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schema_migrations`
--

DROP TABLE IF EXISTS `schema_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `schema_migrations` (
  `version` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  UNIQUE KEY `unique_schema_migrations` (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schema_migrations`
--

LOCK TABLES `schema_migrations` WRITE;
/*!40000 ALTER TABLE `schema_migrations` DISABLE KEYS */;
INSERT INTO `schema_migrations` VALUES ('0');
/*!40000 ALTER TABLE `schema_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `specimen`
--

DROP TABLE IF EXISTS `specimen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `specimen` (
  `specimen_id` int NOT NULL AUTO_INCREMENT,
  `client_id` int DEFAULT NULL,
  `specimen_type_id` int DEFAULT NULL,
  `priority` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ordering_location` int DEFAULT NULL,
  `drawn_by` int DEFAULT NULL,
  `drawn_by_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status_id` int DEFAULT NULL,
  `accepted_by` int DEFAULT NULL,
  `rejected_by` int DEFAULT NULL,
  `rejection_reason_id` int DEFAULT NULL,
  `creator` int DEFAULT NULL,
  `voided` tinyint(1) NOT NULL DEFAULT '0',
  `voided_by` int DEFAULT NULL,
  `void_reason` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`specimen_id`),
  KEY `fk_specimen_1` (`client_id`),
  KEY `fk_specimen_2` (`specimen_type_id`),
  KEY `fk_specimen_4` (`ordering_location`),
  KEY `fk_specimen_3` (`drawn_by`),
  KEY `fk_specimen_6` (`accepted_by`),
  KEY `fk_specimen_7` (`rejected_by`),
  KEY `fk_specimen_8` (`status_id`),
  CONSTRAINT `fk_specimen_1` FOREIGN KEY (`client_id`) REFERENCES `client` (`client_id`),
  CONSTRAINT `fk_specimen_2` FOREIGN KEY (`specimen_type_id`) REFERENCES `specimen_type` (`specimen_type_id`),
  CONSTRAINT `fk_specimen_3` FOREIGN KEY (`drawn_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `fk_specimen_4` FOREIGN KEY (`ordering_location`) REFERENCES `location` (`location_id`),
  CONSTRAINT `fk_specimen_6` FOREIGN KEY (`accepted_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `fk_specimen_7` FOREIGN KEY (`rejected_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `fk_specimen_8` FOREIGN KEY (`status_id`) REFERENCES `status` (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `specimen`
--

LOCK TABLES `specimen` WRITE;
/*!40000 ALTER TABLE `specimen` DISABLE KEYS */;
/*!40000 ALTER TABLE `specimen` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `specimen_test_type`
--

DROP TABLE IF EXISTS `specimen_test_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `specimen_test_type` (
  `specimen_test_type_id` int NOT NULL AUTO_INCREMENT,
  `specimen_type_id` int DEFAULT NULL,
  `test_type_id` int DEFAULT NULL,
  `voided` tinyint(1) NOT NULL DEFAULT '0',
  `voided_by` int DEFAULT NULL,
  `void_reason` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`specimen_test_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `specimen_test_type`
--

LOCK TABLES `specimen_test_type` WRITE;
/*!40000 ALTER TABLE `specimen_test_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `specimen_test_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `specimen_type`
--

DROP TABLE IF EXISTS `specimen_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `specimen_type` (
  `specimen_type_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lifespan` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `creator` int DEFAULT NULL,
  `voided` tinyint(1) NOT NULL DEFAULT '0',
  `voided_by` int DEFAULT NULL,
  `void_reason` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`specimen_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `specimen_type`
--

LOCK TABLES `specimen_type` WRITE;
/*!40000 ALTER TABLE `specimen_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `specimen_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `status`
--

DROP TABLE IF EXISTS `status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `status` (
  `status_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `creator` int DEFAULT NULL,
  `voided` tinyint(1) NOT NULL DEFAULT '0',
  `voided_by` int DEFAULT NULL,
  `void_reason` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `status`
--

LOCK TABLES `status` WRITE;
/*!40000 ALTER TABLE `status` DISABLE KEYS */;
/*!40000 ALTER TABLE `status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `test`
--

DROP TABLE IF EXISTS `test`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `test` (
  `test_id` int NOT NULL AUTO_INCREMENT,
  `specimen_id` int DEFAULT NULL,
  `test_type_id` int DEFAULT NULL,
  `tested_by` int DEFAULT NULL,
  `verified_by` int DEFAULT NULL,
  `requested_by` int DEFAULT NULL,
  `status_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `creator` int DEFAULT NULL,
  `voided` tinyint(1) NOT NULL DEFAULT '0',
  `voided_by` int DEFAULT NULL,
  `void_reason` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`test_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `test`
--

LOCK TABLES `test` WRITE;
/*!40000 ALTER TABLE `test` DISABLE KEYS */;
/*!40000 ALTER TABLE `test` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `test_panel`
--

DROP TABLE IF EXISTS `test_panel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `test_panel` (
  `panel_id` int NOT NULL AUTO_INCREMENT,
  `panel_type_id` int DEFAULT NULL,
  `creator` int DEFAULT NULL,
  `voided` tinyint(1) NOT NULL DEFAULT '0',
  `voided_by` int DEFAULT NULL,
  `void_reason` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`panel_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `test_panel`
--

LOCK TABLES `test_panel` WRITE;
/*!40000 ALTER TABLE `test_panel` DISABLE KEYS */;
/*!40000 ALTER TABLE `test_panel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `test_parameter`
--

DROP TABLE IF EXISTS `test_parameter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `test_parameter` (
  `test_parameter_id` int NOT NULL AUTO_INCREMENT,
  `test_type_id` int DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `list` text COLLATE utf8_unicode_ci,
  `voided` tinyint(1) NOT NULL DEFAULT '0',
  `voided_by` int DEFAULT NULL,
  `void_reason` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`test_parameter_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `test_parameter`
--

LOCK TABLES `test_parameter` WRITE;
/*!40000 ALTER TABLE `test_parameter` DISABLE KEYS */;
/*!40000 ALTER TABLE `test_parameter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `test_result`
--

DROP TABLE IF EXISTS `test_result`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `test_result` (
  `test_result_id` int NOT NULL AUTO_INCREMENT,
  `test_id` int DEFAULT NULL,
  `test_parameter_id` int DEFAULT NULL,
  `result` text COLLATE utf8_unicode_ci,
  `interpretation` text COLLATE utf8_unicode_ci,
  `voided` tinyint(1) NOT NULL DEFAULT '0',
  `voided_by` int DEFAULT NULL,
  `void_reason` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`test_result_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `test_result`
--

LOCK TABLES `test_result` WRITE;
/*!40000 ALTER TABLE `test_result` DISABLE KEYS */;
/*!40000 ALTER TABLE `test_result` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `test_type`
--

DROP TABLE IF EXISTS `test_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `test_type` (
  `test_type_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `department_id` int DEFAULT NULL,
  `creator` int DEFAULT NULL,
  `voided` tinyint(1) NOT NULL DEFAULT '0',
  `voided_by` int DEFAULT NULL,
  `void_reason` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`test_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `test_type`
--

LOCK TABLES `test_type` WRITE;
/*!40000 ALTER TABLE `test_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `test_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `user_id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `first_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `middle_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gender` tinyint NOT NULL DEFAULT '0',
  `designation` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `image` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_password_date` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `user_username_unique` (`username`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'administrator','$2a$12$ue2HXKuRHeutj6YnBoEIDezavflukptWJof2mKrlKG0RzPRhRCiGi','kennethkapundi1@gmail.com','Kenneth','Moses','Kapundi',1,'Software Developer','/uploads/administrator',NULL,NULL,NULL,'2021-06-24 11:33:04','2022-03-23 10:32:12'),(2,'jasper','$2a$12$fSG7.A5LG6Ct66hnwOC.9eq9nBGY3x49WGMW6I0R2yzV5YvJU7cx6','js@gmail.com','jspaer',NULL,'CHisi',1,'Nurse','/uploads/jasper',NULL,NULL,NULL,'2022-03-16 07:47:42','2022-03-16 07:47:42');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_role`
--

DROP TABLE IF EXISTS `user_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_role` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `role_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_role_user_id_foreign` (`user_id`) USING BTREE,
  KEY `user_role_role_id_foreign` (`role_id`) USING BTREE,
  CONSTRAINT `fk_user_role_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`),
  CONSTRAINT `fk_user_role_2` FOREIGN KEY (`role_id`) REFERENCES `role` (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb3 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_role`
--

LOCK TABLES `user_role` WRITE;
/*!40000 ALTER TABLE `user_role` DISABLE KEYS */;
INSERT INTO `user_role` VALUES (5,1,1),(6,2,2),(7,2,3);
/*!40000 ALTER TABLE `user_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `workflow`
--

DROP TABLE IF EXISTS `workflow`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `workflow` (
  `workflow_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `creator` int DEFAULT NULL,
  `voided` tinyint(1) NOT NULL DEFAULT '0',
  `voided_by` int DEFAULT NULL,
  `void_reason` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`workflow_id`),
  KEY `fk_workflow_1` (`voided_by`),
  KEY `fk_workflow_2` (`creator`),
  CONSTRAINT `fk_workflow_1` FOREIGN KEY (`voided_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `fk_workflow_2` FOREIGN KEY (`creator`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `workflow`
--

LOCK TABLES `workflow` WRITE;
/*!40000 ALTER TABLE `workflow` DISABLE KEYS */;
INSERT INTO `workflow` VALUES (1,'HTS',NULL,NULL,0,NULL,NULL,'2022-03-23 09:31:03','2022-03-23 09:31:03'),(2,'ART',NULL,NULL,0,NULL,NULL,'2022-03-25 05:11:05','2022-03-25 05:11:05');
/*!40000 ALTER TABLE `workflow` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `workflow_encounter_type`
--

DROP TABLE IF EXISTS `workflow_encounter_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `workflow_encounter_type` (
  `workflow_encounter_type_id` int NOT NULL AUTO_INCREMENT,
  `workflow_id` int DEFAULT NULL,
  `encounter_type_id` int DEFAULT NULL,
  `sort_order` int DEFAULT NULL,
  `creator` int DEFAULT NULL,
  `voided` tinyint(1) NOT NULL DEFAULT '0',
  `voided_by` int DEFAULT NULL,
  `void_reason` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`workflow_encounter_type_id`),
  KEY `fk_workflow_encounter_type_1` (`voided_by`),
  KEY `fk_workflow_encounter_type_2` (`creator`),
  KEY `fk_workflow_encounter_type_3` (`workflow_id`),
  KEY `fk_workflow_encounter_type_4` (`encounter_type_id`),
  CONSTRAINT `fk_workflow_encounter_type_1` FOREIGN KEY (`voided_by`) REFERENCES `user` (`user_id`),
  CONSTRAINT `fk_workflow_encounter_type_2` FOREIGN KEY (`creator`) REFERENCES `user` (`user_id`),
  CONSTRAINT `fk_workflow_encounter_type_3` FOREIGN KEY (`workflow_id`) REFERENCES `workflow` (`workflow_id`),
  CONSTRAINT `fk_workflow_encounter_type_4` FOREIGN KEY (`encounter_type_id`) REFERENCES `encounter_type` (`encounter_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `workflow_encounter_type`
--

LOCK TABLES `workflow_encounter_type` WRITE;
/*!40000 ALTER TABLE `workflow_encounter_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `workflow_encounter_type` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-04-07 12:50:01
